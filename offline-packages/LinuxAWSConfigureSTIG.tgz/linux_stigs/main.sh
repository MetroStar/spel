#!/usr/bin/env bash

function usage() {
    echo "Usage: $0 [options]"
    echo
    echo "Options:"
    echo "  -d:    Specify the current working directory"
    echo "  -l:    Specify the STIG level."
    echo "  -h:    Specify whether packages should be installed. (yes/no)"
    echo "  -s:    Specify whether legal banner should be set. (yes/no)"
}

# Setting variable for default input
while getopts d:l:h:s: options
do
    case "${options}" in
        d) WorkingDir=${OPTARG};;
        l) Level=${OPTARG};;
        h) HandlePackages=${OPTARG};;
        s) SetLegalBanner=${OPTARG};;
        *) usage;;
    esac
done

if [ -z "${WorkingDir}" ]; then
    echo
    echo -e "Working directory not defined. Exiting.\n $(usage). "
    exit 1
fi

source "/etc/os-release"
RELEASE="$ID${VERSION_ID:+.${VERSION_ID}}"
FUNC_DIR="${WorkingDir}functions"
VERSION=$ID${VERSION_ID%.*}
# Determine the release and setup variables
case "${RELEASE}" in
    amzn.*|centos.*|rhel.*|ol.*)
        SEARCH="rpm -q"
        ID="rhel"
        OS_FUNCS="${FUNC_DIR}/${ID}"
        SOURCE="${OS_FUNCS}/rhel_common_funcs.sh"
        AUDIT_PACKAGE="audit"
        ;;&
    amzn.2|centos.7*|rhel.7*)
        SCRIPT=rhel7_stig.sh
        AUDIT_PACKAGE="auditd"
        ;;
    centos.8*|rhel.8*)
        SCRIPT=rhel8_stig.sh
        ;;
    amzn.2023)
        SCRIPT=al2023_stig.sh
        ID="amzn"
        OS_FUNCS="${FUNC_DIR}/${ID}"
        ;;
    centos.9*|rhel.9*)
        SCRIPT=rhel9_stig.sh
        ;;
    ubuntu.*)
        SEARCH="dpkg -l"
        ID="ubuntu"
        OS_FUNCS="${FUNC_DIR}/${ID}"
        SOURCE="${OS_FUNCS}/ubuntu_common_funcs.sh"
        AUDIT_PACKAGE="auditd"
        ;;&
    ubuntu.18*) SCRIPT=ubuntu18_stig.sh ;;
    ubuntu.20*) SCRIPT=ubuntu20_stig.sh ;;
    ubuntu.22*) SCRIPT=ubuntu22_stig.sh ;;
    ubuntu.24*) SCRIPT=ubuntu24_stig.sh ;;
    sles.*)
        SEARCH="rpm -q"
        ID="sles"
        OS_FUNCS="${FUNC_DIR}/${ID}"
        SOURCE="${OS_FUNCS}/sles_common_funcs.sh"
        AUDIT_PACKAGE="audit"
        ;;&
    sles.12*) SCRIPT=sles12_stig.sh;;
    sles.15*) SCRIPT=sles15_stig.sh;;
    ol.*)
        ID="ol"
        OS_FUNCS="${FUNC_DIR}/${ID}"
        ;;&
    ol.7*) SCRIPT=ol7_stig.sh;;
    ol.8*) SCRIPT=ol8_stig.sh;;
    ol.9*) SCRIPT=ol9_stig.sh;;
    *)
        echo "Operating System '${RELEASE}' is not supported. Exiting."
        exit 1
        ;;
esac

source "$SOURCE"
source "${OS_FUNCS}"/"${SCRIPT}"
